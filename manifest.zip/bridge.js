// bridge.js — ISOLATED world content script
// inject.js를 MAIN world에 주입하여 WebSocket monkey-patch 실행
const s = document.createElement('script');
s.src = chrome.runtime.getURL('inject.js');
s.onload = () => s.remove();
(document.head || document.documentElement).appendChild(s);
