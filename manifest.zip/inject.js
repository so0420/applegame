// ============================================
// 사과게임 보조 — Chrome 확장 (MAIN world 주입)
// WebSocket 전송 경로가 막혀 있으므로 solver 결과를
// 팝업 보드에 시각화하고, 사용자가 직접 드래그로 플레이한다.
// ============================================

(function () {
    'use strict';

    const TARGET_URL = 'apple.oshizi.com/socket.io';
    const PLAN_TIME_LIMIT_MS = 90 * 1000;
    const ROWS = 10, COLS = 17, BOARD_SIZE = 170;
    const CELL = 32, GAP = 2, PAD = 4, PITCH = CELL + GAP;
    const GRID_W_PX = COLS * CELL + (COLS - 1) * GAP + 2 * PAD;
    const GRID_H_PX = ROWS * CELL + (ROWS - 1) * GAP + 2 * PAD;

    let _solveRunning = false;
    let _ws = null;
    let _lastBoard = null;
    let _lastScore = 0;
    let _stopRequested = false;
    let _worker = null;
    let _solveResolve = null;
    let _bestIntermediate = null;   // worker에서 올라온 현재까지 최고 plan

    // 팝업 상태
    let _popBoard = null;
    let _popInitial = null;
    let _popPlan = [];
    let _popPlanIdx = 0;
    let _popScore = 0;
    let _popCellDrag = null;   // {sr,sc,er,ec}
    let _popWinDrag = null;    // {dx,dy}
    let _popCells = null;      // cell DOM refs (길이 170)
    let _popHistory = [];      // undo 스택
    let _popAnimating = false; // 애니메이션 중 입력 차단
    let _popScale = parseFloat(localStorage.getItem('as-scale') || '1') || 1;
    let _popResize = null;     // {sx, sy, startScale}
    const FADE_MS = 280;

    // ============================================
    // Solver Worker (Blob URL)
    // ============================================
    function solverWorkerFn() {
        'use strict';
        const ROWS = 10, COLS = 17, BOARD_SIZE = 170;
        const PS_W = 18, PS_SIZE = 198, MAX_REGIONS = 100000;

        const _ps = new Int16Array(PS_SIZE);
        const _pnz = new Int16Array(PS_SIZE);
        const _pdg = new Int16Array(PS_SIZE);
        const _regR1 = new Uint8Array(MAX_REGIONS);
        const _regC1 = new Uint8Array(MAX_REGIONS);
        const _regR2 = new Uint8Array(MAX_REGIONS);
        const _regC2 = new Uint8Array(MAX_REGIONS);
        const _regNz = new Uint16Array(MAX_REGIONS);
        const _regDg = new Uint16Array(MAX_REGIONS);
        const _used  = new Uint8Array(MAX_REGIONS);
        const _cov   = new Uint8Array(BOARD_SIZE);

        function copyBoard(b) { return b.slice(); }
        function clearReg(bd, r1, c1, r2, c2) {
            for (let r = r1; r <= r2; r++) { const b = r*COLS; for (let c = c1; c <= c2; c++) bd[b+c] = 0; }
        }

        function buildPS(bd) {
            for (let c = 0; c < PS_W; c++) _ps[c] = _pnz[c] = _pdg[c] = 0;
            for (let r = 1; r <= ROWS; r++) {
                const ri = r * PS_W; _ps[ri] = _pnz[ri] = _pdg[ri] = 0;
                for (let c = 1; c <= COLS; c++) {
                    const v = bd[(r-1)*COLS+(c-1)];
                    const i = ri+c, u = i-PS_W, l = i-1, d = u-1;
                    _ps[i]  = v + _ps[u] + _ps[l] - _ps[d];
                    _pnz[i] = (v>0?1:0) + _pnz[u] + _pnz[l] - _pnz[d];
                    _pdg[i] = (v>=7?v-6:0) + _pdg[u] + _pdg[l] - _pdg[d];
                }
            }
        }

        function findRegions(bd, cov) {
            if (cov) _cov.fill(0);
            buildPS(bd);
            let cnt = 0;
            for (let r1 = 0; r1 < ROWS; r1++)
              for (let c1 = 0; c1 < COLS; c1++)
                for (let r2 = r1; r2 < ROWS; r2++) {
                    const cS = _ps[(r2+1)*PS_W+c1+1] - _ps[r1*PS_W+c1+1] - _ps[(r2+1)*PS_W+c1] + _ps[r1*PS_W+c1];
                    if (cS > 10) break;
                    const tl = r1*PS_W+c1, bl = (r2+1)*PS_W+c1;
                    for (let c2 = c1; c2 < COLS; c2++) {
                        const tr = r1*PS_W+c2+1, br = (r2+1)*PS_W+c2+1;
                        const sum = _ps[br]-_ps[tr]-_ps[bl]+_ps[tl];
                        if (sum > 10) break;
                        if (sum !== 10) continue;
                        const nz = _pnz[br]-_pnz[tr]-_pnz[bl]+_pnz[tl];
                        if (nz < 2) continue;
                        if (cov) {
                            for (let r = r1; r <= r2; r++) { const b = r*COLS; for (let c = c1; c <= c2; c++) if (bd[b+c]>0) _cov[b+c]=1; }
                        }
                        if (cnt >= MAX_REGIONS) return cnt;
                        _regR1[cnt]=r1; _regC1[cnt]=c1; _regR2[cnt]=r2; _regC2[cnt]=c2;
                        _regNz[cnt]=nz; _regDg[cnt]=_pdg[br]-_pdg[tr]-_pdg[bl]+_pdg[tl];
                        cnt++;
                    }
                }
            return cnt;
        }

        function covNZ() { let n=0; for(let i=0;i<BOARD_SIZE;i++) if(_cov[i]) n++; return n; }

        function bestIdx(cnt) {
            let b=0;
            for(let i=1;i<cnt;i++) if(_regDg[i]>_regDg[b]||(_regDg[i]===_regDg[b]&&_regNz[i]>_regNz[b])) b=i;
            return b;
        }

        function topK(cnt, k) {
            k = Math.min(cnt, k);
            const c = new Array(k); _used.fill(0,0,cnt);
            for (let j=0;j<k;j++) {
                let b=-1, bs=-1;
                for(let i=0;i<cnt;i++) {
                    if(_used[i]) continue;
                    const a=(_regR2[i]-_regR1[i]+1)*(_regC2[i]-_regC1[i]+1);
                    const s=_regDg[i]*100+_regNz[i]*10+(_regNz[i]/a)*5;
                    if(s>bs){b=i;bs=s;}
                }
                c[j]={r1:_regR1[b],c1:_regC1[b],r2:_regR2[b],c2:_regC2[b],nz:_regNz[b]};
                _used[b]=1;
            }
            return c;
        }

        function hashBd(bd) {
            let h=0x811c9dc5|0;
            for(let i=0;i<BOARD_SIZE;i++){h^=bd[i];h=Math.imul(h,0x01000193);}
            return h|0;
        }

        function greedy(bd) {
            bd=copyBoard(bd); const plan=[]; let score=0;
            while(true) {
                const cnt=findRegions(bd,false); if(cnt===0) break;
                const i=bestIdx(cnt);
                plan.push({r1:_regR1[i],c1:_regC1[i],r2:_regR2[i],c2:_regC2[i],nz:_regNz[i]});
                score+=_regNz[i]; clearReg(bd,_regR1[i],_regC1[i],_regR2[i],_regC2[i]);
            }
            return {plan,score};
        }

        function beamPass(bd, dl, width, k) {
            let beam=[{board:copyBoard(bd),plan:[],score:0}];
            let best={plan:[],score:0}, steps=0;
            while(beam.length>0 && Date.now()<dl) {
                const cands=[];
                for(let si=0;si<beam.length;si++) {
                    if(Date.now()>dl) break;
                    const st=beam[si], cnt=findRegions(st.board,true);
                    if(cnt===0){if(st.score>best.score) best={plan:st.plan,score:st.score}; continue;}
                    const reach=covNZ(), K=Math.min(cnt,k), mvs=topK(cnt,K);
                    for(let mi=0;mi<mvs.length;mi++) {
                        const mv=mvs[mi], nb=copyBoard(st.board);
                        clearReg(nb,mv.r1,mv.c1,mv.r2,mv.c2);
                        const ns=st.score+mv.nz;
                        cands.push({board:nb,plan:[...st.plan,mv],score:ns,h:ns+Math.max(0,reach-mv.nz)});
                    }
                }
                if(cands.length===0) break;
                cands.sort((a,b)=>b.h-a.h);
                const seen=new Set(), div=[];
                for(let i=0;i<cands.length&&div.length<width;i++){const h=hashBd(cands[i].board);if(!seen.has(h)){seen.add(h);div.push(cands[i]);}}
                beam=div;
                const gn=Math.min(beam.length,3);
                for(let gi=0;gi<gn&&Date.now()<dl;gi++){
                    const s=beam[gi],g=greedy(s.board),t=s.score+g.score;
                    if(t>best.score) best={plan:[...s.plan,...g.plan],score:t};
                }
                steps++;
            }
            for(let si=0;si<beam.length&&Date.now()<dl;si++){
                const st=beam[si],g=greedy(st.board),t=st.score+g.score;
                if(t>best.score) best={plan:[...st.plan,...g.plan],score:t};
            }
            return {plan:best.plan,score:best.score,steps};
        }

        self.onmessage = function(e) {
            if (e.data.type !== 'solve') return;
            const bd = new Uint8Array(e.data.board);
            const dl = Date.now() + e.data.timeLimit;

            const gr = greedy(bd);
            self.postMessage({type:'log', msg:'그리디: '+gr.plan.length+'개, '+gr.score+'점'});

            let best = {plan:gr.plan, score:gr.score};
            self.postMessage({type:'progress', plan:best.plan, score:best.score});
            let width=5000, k=10, round=0;
            while (Date.now() < dl - 500) {
                round++;
                const t0 = Date.now();
                const res = beamPass(bd, dl, width, k);
                if (res.score > best.score) {
                    best = {plan:res.plan, score:res.score};
                    self.postMessage({type:'progress', plan:best.plan, score:best.score});
                }
                const elapsed = Date.now()-t0, rem = dl-Date.now();
                if (rem < 1000) break;
                const sc = Math.min(3, (rem*0.9)/Math.max(100,elapsed));
                width = Math.min(20000, Math.ceil(width*sc));
                k = Math.min(30, k+3);
                self.postMessage({type:'log', msg:'round '+round+': '+res.score+'점 ('+(elapsed/1000).toFixed(1)+'초), next W='+width+' K='+k});
            }
            self.postMessage({type:'log', msg:'beam 총 '+round+'라운드, best '+best.score+'점 (그리디+' + (best.score - gr.score) + ')'});
            self.postMessage({type:'result', plan:best.plan, score:best.score, greedyScore:gr.score});
        };
    }

    function createWorker() {
        if (_worker) _worker.terminate();
        const code = '(' + solverWorkerFn.toString() + ')()';
        const blob = new Blob([code], {type: 'text/javascript'});
        _worker = new Worker(URL.createObjectURL(blob));
        _worker.onmessage = function(e) {
            const d = e.data;
            if (d.type === 'log') uiLog(d.msg);
            else if (d.type === 'progress') {
                _bestIntermediate = { plan: d.plan, score: d.score };
                uiStatus(`계산 중... 최고 ${d.score}점 (풀이 시작=즉시 적용)`);
            }
            else if (d.type === 'result' && _solveResolve) {
                _solveResolve(d);
                _solveResolve = null;
            }
        };
    }

    // ============================================
    // 컨트롤 패널
    // ============================================
    function createUI() {
        const panel = document.createElement('div');
        panel.id = 'apple-solver-panel';
        panel.innerHTML = `
            <style>
                #apple-solver-panel {
                    position: fixed; top: 10px; right: 10px; z-index: 99999;
                    background: #1a1a2e; color: #eee; border-radius: 12px;
                    padding: 14px 18px; font-family: monospace; font-size: 13px;
                    min-width: 260px; box-shadow: 0 4px 20px rgba(0,0,0,0.5);
                    user-select: none;
                }
                #apple-solver-panel .title-bar { display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; }
                #apple-solver-panel .title { font-size:15px; font-weight:bold; color:#e94560; }
                #apple-solver-panel .btn-min {
                    background:none; border:1px solid #555; color:#aaa;
                    border-radius:4px; cursor:pointer; font-size:14px;
                    width:24px; height:24px; padding:0;
                }
                #apple-solver-panel .btn-min:hover { border-color:#e94560; color:#e94560; }
                #apple-solver-panel .body.hidden { display:none; }
                #apple-solver-panel .status { margin:4px 0; color:#aaa; }
                #apple-solver-panel .score { font-size:18px; font-weight:bold; color:#4caf50; }
                #apple-solver-panel .log {
                    max-height:150px; overflow-y:auto; margin-top:8px;
                    font-size:11px; color:#888; border-top:1px solid #333; padding-top:6px;
                }
                #apple-solver-panel .log div { margin:1px 0; }
                #apple-solver-panel button.action {
                    margin-top:8px; padding:6px 14px; border:none; border-radius:6px;
                    font-size:13px; font-weight:bold; cursor:pointer;
                }
                #apple-solver-panel .btn-solve { background:#e94560; color:#fff; }
                #apple-solver-panel .btn-solve:disabled { background:#555; cursor:default; }
                #apple-solver-panel .btn-stop { background:#333; color:#ccc; margin-left:6px; }
                #apple-solver-panel .btn-show { background:#0f88aa; color:#fff; margin-left:6px; }
            </style>
            <div class="title-bar">
                <span class="title">🍎 Apple Solver</span>
                <button class="btn-min" id="as-btn-min" title="최소화">−</button>
            </div>
            <div class="body" id="as-body">
                <div class="status" id="as-status">대기 중...</div>
                <div class="status">점수: <span class="score" id="as-score">-</span></div>
                <div>
                    <button class="action btn-solve" id="as-btn-solve" disabled>풀이 시작</button>
                    <button class="action btn-stop" id="as-btn-stop" style="display:none">중지</button>
                    <button class="action btn-show" id="as-btn-show">보드 열기</button>
                </div>
                <div class="log" id="as-log"></div>
            </div>
        `;
        document.body.appendChild(panel);

        const body = document.getElementById('as-body');
        const minBtn = document.getElementById('as-btn-min');
        if (localStorage.getItem('as-minimized') === '1') { body.classList.add('hidden'); minBtn.textContent = '+'; }
        minBtn.addEventListener('click', () => {
            const h = body.classList.toggle('hidden');
            minBtn.textContent = h ? '+' : '−';
            localStorage.setItem('as-minimized', h ? '1' : '0');
        });

        document.getElementById('as-btn-solve').addEventListener('click', () => {
            if (_solveRunning) {
                // 계산 중 — 현재까지 최고점으로 즉시 종료하고 힌트 표시
                if (_solveResolve) {
                    const best = _bestIntermediate;
                    _solveResolve({
                        plan: best && best.plan ? best.plan : [],
                        score: best ? best.score : 0,
                        greedyScore: 0,
                        earlyStop: true
                    });
                    _solveResolve = null;
                    createWorker();
                    uiLog(best ? `조기 적용: ${best.score}점` : '조기 적용: 결과 없음');
                }
            } else if (_lastBoard) {
                solveGame(_lastBoard, _lastScore);
            }
        });
        document.getElementById('as-btn-stop').addEventListener('click', () => {
            _stopRequested = true;
            if (_solveResolve) {
                _solveResolve({plan:[], score:0, greedyScore:0});
                _solveResolve = null;
                createWorker();
                uiLog('Worker 강제 중지');
            }
        });
        document.getElementById('as-btn-show').addEventListener('click', () => {
            const pop = document.getElementById('apple-board-popup');
            if (pop) pop.classList.toggle('visible');
        });
    }

    function uiStatus(t) { const e = document.getElementById('as-status'); if (e) e.textContent = t; }
    function uiScore(n)  { const e = document.getElementById('as-score');  if (e) e.textContent = n; }
    function uiLog(t) {
        const e = document.getElementById('as-log'); if (!e) return;
        const d = document.createElement('div'); d.textContent = t; e.prepend(d);
        while (e.children.length > 50) e.lastChild.remove();
        console.log('[solver] ' + t);
    }
    function uiBtnState(solving) {
        const b = document.getElementById('as-btn-solve');
        const s = document.getElementById('as-btn-stop');
        // solve 중에도 '풀이 시작'을 누르면 현재 최고점 조기 적용 — 비활성화하지 않음
        if (b) b.disabled = !_lastBoard;
        if (s) s.style.display = solving ? 'inline' : 'none';
    }

    // ============================================
    // 보드 팝업
    // ============================================
    function createBoardPopup() {
        const pop = document.createElement('div');
        pop.id = 'apple-board-popup';
        pop.innerHTML = `
            <style>
                #apple-board-popup {
                    position: fixed; top: 120px; left: 120px; z-index: 99998;
                    background: rgba(42, 42, 62, 0.55); color: #eee; border-radius: 12px;
                    font-family: monospace; box-shadow: 0 4px 20px rgba(0,0,0,0.5);
                    user-select: none; display: none;
                    /* 보드 영역 클릭/드래그는 뒷 게임으로 통과시킨다 — 헤더만 .ph에서 auto로 복구 */
                    pointer-events: none;
                    backdrop-filter: blur(1px);
                }
                #apple-board-popup.visible { display: block; }
                #apple-board-popup .ph {
                    background: rgba(26, 26, 46, 0.85); padding: 8px 12px;
                    border-radius: 12px 12px 0 0; cursor: move;
                    display: flex; justify-content: space-between; align-items: center;
                    pointer-events: auto;
                }
                #apple-board-popup .ph .ttl { font-weight:bold; color:#e94560; font-size:14px; }
                #apple-board-popup .ph .tools { display:flex; gap:4px; }
                #apple-board-popup .ph button {
                    background:#333; border:1px solid #555; color:#ccc;
                    border-radius:4px; cursor:pointer; padding:2px 8px;
                    font-size:12px; font-family:monospace;
                }
                #apple-board-popup .ph button:hover { border-color:#e94560; color:#e94560; }
                #apple-board-popup .pb { padding: 12px; padding-bottom: 16px; }
                #apple-board-popup .grid-wrap {
                    position: relative;
                    width: calc(${GRID_W_PX}px * var(--scale, 1));
                    height: calc(${GRID_H_PX}px * var(--scale, 1));
                }
                #apple-board-popup .grid {
                    position: relative;
                    display: grid;
                    grid-template-columns: repeat(${COLS}, ${CELL}px);
                    grid-template-rows: repeat(${ROWS}, ${CELL}px);
                    gap: ${GAP}px;
                    background: rgba(17, 17, 17, 0.35); padding: ${PAD}px; border-radius: 6px;
                    transform: scale(var(--scale, 1));
                    transform-origin: top left;
                }
                #apple-board-popup .cell {
                    display:flex; align-items:center; justify-content:center;
                    background: rgba(211, 47, 47, 0.75); color:#fff; border-radius:50%;
                    font-weight:bold; font-size:14px;
                    width:${CELL}px; height:${CELL}px;
                    box-sizing:border-box;
                    text-shadow: 0 0 3px rgba(0,0,0,0.9);
                }
                #apple-board-popup .cell.empty { background:transparent; color:transparent; }
                #apple-board-popup .cell.fading {
                    animation: appleFade ${FADE_MS}ms cubic-bezier(0.4, 0, 0.6, 1) forwards;
                }
                #apple-board-popup .cell.appearing {
                    animation: appleAppear 220ms ease-out;
                }
                @keyframes appleFade {
                    0%   { transform: scale(1);    opacity: 1; }
                    40%  { transform: scale(1.25); opacity: 0.9; background:#ff5252; }
                    100% { transform: scale(0);    opacity: 0; }
                }
                @keyframes appleAppear {
                    0%   { transform: scale(0);    opacity: 0; }
                    60%  { transform: scale(1.15); opacity: 1; }
                    100% { transform: scale(1);    opacity: 1; }
                }
                #apple-board-popup .overlay { position:absolute; pointer-events:none; box-sizing:border-box; border-radius:4px; }
                #apple-board-popup .hint-box {
                    border: 3px dashed #ffeb3b;
                    background: rgba(255,235,59,0.15);
                    z-index: 2;
                }
                #apple-board-popup .drag-box {
                    border: 2px solid #4fc3f7;
                    background: rgba(79,195,247,0.22);
                    z-index: 3;
                }
                #apple-board-popup .info {
                    margin-top:8px; font-size:12px; color:#aaa;
                    display:flex; justify-content:space-between; gap:10px;
                }
                #apple-board-popup .info .ok { color:#4caf50; font-weight:bold; }
                #apple-board-popup .info .bad { color:#f44336; }
                #apple-board-popup .resize {
                    position: absolute; right: 0; bottom: 0;
                    width: 18px; height: 18px;
                    cursor: nwse-resize;
                    pointer-events: auto;
                    background:
                        linear-gradient(135deg,
                            transparent 0, transparent 55%,
                            #e94560 55%, #e94560 62%,
                            transparent 62%, transparent 72%,
                            #e94560 72%, #e94560 79%,
                            transparent 79%, transparent 89%,
                            #e94560 89%, #e94560 96%,
                            transparent 96%);
                    border-radius: 0 0 12px 0;
                }
            </style>
            <div class="ph" id="pop-header">
                <span class="ttl">🍎 Board</span>
                <span class="tools">
                    <button id="pop-reset" title="초기 보드로 리셋">리셋</button>
                    <button id="pop-hint-prev" title="이전 힌트 (A)">◀</button>
                    <button id="pop-hint-next" title="다음 힌트 (D)">▶</button>
                    <button id="pop-hint-toggle" title="힌트 표시/숨김">힌트</button>
                    <button id="pop-close" title="닫기">×</button>
                </span>
            </div>
            <div class="pb">
                <div class="grid-wrap">
                    <div class="grid" id="pop-grid"></div>
                </div>
                <div class="info">
                    <span id="pop-msg">보드 로딩 대기 중</span>
                    <span>점수 <span class="ok" id="pop-score">0</span> · 힌트 <span id="pop-hint-idx">-</span></span>
                </div>
            </div>
            <div class="resize" id="pop-resize" title="크기 조절 (드래그)"></div>
        `;
        document.body.appendChild(pop);
        pop.style.setProperty('--scale', _popScale);

        // 팝업 윈도우 드래그 이동
        const header = document.getElementById('pop-header');
        header.addEventListener('mousedown', (e) => {
            if (e.target.tagName === 'BUTTON') return;
            const r = pop.getBoundingClientRect();
            _popWinDrag = { dx: e.clientX - r.left, dy: e.clientY - r.top };
            e.preventDefault();
        });

        // 크기 조절 핸들
        document.getElementById('pop-resize').addEventListener('mousedown', (e) => {
            _popResize = { sx: e.clientX, sy: e.clientY, startScale: _popScale };
            e.preventDefault();
            e.stopPropagation();
        });

        // 버튼
        document.getElementById('pop-close').addEventListener('click', () => pop.classList.remove('visible'));
        document.getElementById('pop-reset').addEventListener('click', resetPopupBoard);
        document.getElementById('pop-hint-prev').addEventListener('click', undoStep);
        document.getElementById('pop-hint-next').addEventListener('click', applyHintStep);
        document.getElementById('pop-hint-toggle').addEventListener('click', () => {
            const h = document.querySelector('#apple-board-popup .hint-box');
            if (h) h.style.display = (h.style.display === 'none') ? '' : 'none';
        });

        // 그리드 셀 드래그 (선택)
        const grid = document.getElementById('pop-grid');
        grid.addEventListener('mousedown', (e) => {
            const p = cellAt(grid, e); if (!p) return;
            _popCellDrag = { sr: p.r, sc: p.c, er: p.r, ec: p.c };
            renderDragBox();
            e.preventDefault();
        });

        // 전역 move / up (드래그가 셀 밖으로 나가도 추적)
        document.addEventListener('mousemove', (e) => {
            if (_popResize) {
                // 대각선 이동 평균으로 스케일 조절 (aspect ratio는 고정)
                const dx = e.clientX - _popResize.sx;
                const dy = e.clientY - _popResize.sy;
                const delta = (dx / GRID_W_PX + dy / GRID_H_PX) / 2;
                _popScale = Math.max(0.3, Math.min(5, _popResize.startScale + delta));
                pop.style.setProperty('--scale', _popScale);
                return;
            }
            if (_popWinDrag) {
                pop.style.left = Math.max(0, e.clientX - _popWinDrag.dx) + 'px';
                pop.style.top = Math.max(0, e.clientY - _popWinDrag.dy) + 'px';
                pop.style.right = 'auto';
                return;
            }
            if (_popCellDrag) {
                const p = cellAt(grid, e);
                if (p) {
                    _popCellDrag.er = p.r;
                    _popCellDrag.ec = p.c;
                    renderDragBox();
                }
            }
        });
        // a/d — 이전/다음 힌트 (팝업이 보일 때만)
        document.addEventListener('keydown', (e) => {
            if (!pop.classList.contains('visible')) return;
            if (e.ctrlKey || e.altKey || e.metaKey) return;
            const t = e.target, tag = (t && t.tagName) || '';
            if (tag === 'INPUT' || tag === 'TEXTAREA' || (t && t.isContentEditable)) return;
            const k = e.key.toLowerCase();
            if (k === 'a') { undoStep(); e.preventDefault(); }
            else if (k === 'd') { applyHintStep(); e.preventDefault(); }
        });

        document.addEventListener('mouseup', () => {
            if (_popResize) {
                localStorage.setItem('as-scale', String(_popScale));
                _popResize = null;
                return;
            }
            if (_popWinDrag) { _popWinDrag = null; return; }
            if (!_popCellDrag) return;
            const r1 = Math.min(_popCellDrag.sr, _popCellDrag.er);
            const r2 = Math.max(_popCellDrag.sr, _popCellDrag.er);
            const c1 = Math.min(_popCellDrag.sc, _popCellDrag.ec);
            const c2 = Math.max(_popCellDrag.sc, _popCellDrag.ec);
            _popCellDrag = null;
            const box = grid.querySelector('.drag-box');
            if (box) box.remove();
            commitSelection(r1, c1, r2, c2);
        });
    }

    function cellAt(grid, e) {
        const rect = grid.getBoundingClientRect();
        const x = e.clientX - rect.left - PAD;
        const y = e.clientY - rect.top - PAD;
        let c = Math.floor(x / PITCH);
        let r = Math.floor(y / PITCH);
        if (r < 0) r = 0; else if (r >= ROWS) r = ROWS - 1;
        if (c < 0) c = 0; else if (c >= COLS) c = COLS - 1;
        return { r, c };
    }

    function showBoardPopup() {
        const pop = document.getElementById('apple-board-popup');
        if (pop) pop.classList.add('visible');
    }

    function resetPopupBoard() {
        if (!_popInitial || _popAnimating) return;
        // 현재 0이었다가 복원되는 셀은 appear 애니메이션
        const appearIdx = [];
        for (let i = 0; i < BOARD_SIZE; i++) {
            if ((!_popBoard || _popBoard[i] === 0) && _popInitial[i] > 0) appearIdx.push(i);
        }
        _popBoard = _popInitial.slice();
        _popPlanIdx = 0;
        _popScore = 0;
        _popHistory = [];
        renderBoard();
        renderHint();
        animateAppear(appearIdx);
        setPopMsg('리셋됨');
    }

    function pushHistory() {
        _popHistory.push({
            board: _popBoard.slice(),
            score: _popScore,
            planIdx: _popPlanIdx
        });
        if (_popHistory.length > 500) _popHistory.shift();
    }

    function buildCellsIfNeeded() {
        const grid = document.getElementById('pop-grid');
        if (!grid) return;
        if (_popCells && _popCells.length === BOARD_SIZE && _popCells[0].parentNode === grid) return;
        grid.querySelectorAll('.cell').forEach(n => n.remove());
        _popCells = new Array(BOARD_SIZE);
        for (let i = 0; i < BOARD_SIZE; i++) {
            const cell = document.createElement('div');
            cell.className = 'cell empty';
            grid.appendChild(cell);
            _popCells[i] = cell;
        }
        // overlay가 있었다면 맨 뒤로
        Array.from(grid.querySelectorAll('.overlay')).forEach(o => grid.appendChild(o));
    }

    function animateAppear(indices) {
        if (!_popCells || !indices || indices.length === 0) return;
        indices.forEach(i => {
            const cell = _popCells[i];
            if (!cell) return;
            cell.classList.remove('appearing');
            // reflow로 재시작
            void cell.offsetWidth;
            cell.classList.add('appearing');
            setTimeout(() => cell.classList.remove('appearing'), 240);
        });
    }

    function applyHintStep() {
        if (!_popBoard || _popAnimating) return;
        if (_popPlanIdx >= _popPlan.length) { setPopMsg('더 이상 힌트 없음'); return; }
        const m = _popPlan[_popPlanIdx];
        const cleared = [];
        let nz = 0;
        for (let r = m.r1; r <= m.r2; r++) {
            for (let c = m.c1; c <= m.c2; c++) {
                const i = r * COLS + c;
                if (_popBoard[i] > 0) { cleared.push(i); nz++; }
            }
        }
        if (cleared.length === 0) {
            _popPlanIdx++;
            renderHint();
            setPopMsg('빈 힌트 건너뜀');
            return;
        }
        pushHistory();
        _popAnimating = true;
        // 애니메이션: 데이터는 아직 그대로, fading 클래스 추가
        cleared.forEach(i => {
            const cell = _popCells[i];
            if (cell) cell.classList.add('fading');
        });
        setPopMsg(`적용 중... +${nz}`, 'ok');
        setTimeout(() => {
            cleared.forEach(i => { _popBoard[i] = 0; });
            _popScore += nz;
            _popPlanIdx++;
            renderBoard();
            renderHint();
            setPopMsg(`+${nz} 사과 (힌트 ${_popPlanIdx}/${_popPlan.length})`, 'ok');
            _popAnimating = false;
        }, FADE_MS);
    }

    function undoStep() {
        if (_popAnimating || _popHistory.length === 0) {
            if (_popHistory.length === 0) setPopMsg('되돌릴 수 없음');
            return;
        }
        const prev = _popHistory.pop();
        const appearIdx = [];
        for (let i = 0; i < BOARD_SIZE; i++) {
            if (_popBoard[i] === 0 && prev.board[i] > 0) appearIdx.push(i);
        }
        _popBoard = prev.board;
        _popScore = prev.score;
        _popPlanIdx = prev.planIdx;
        renderBoard();
        renderHint();
        animateAppear(appearIdx);
        setPopMsg('되돌림');
    }

    function setPopMsg(s, cls) {
        const e = document.getElementById('pop-msg');
        if (!e) return;
        e.textContent = s;
        e.className = cls || '';
    }

    function renderBoard() {
        if (!_popBoard) return;
        buildCellsIfNeeded();
        for (let i = 0; i < BOARD_SIZE; i++) {
            const v = _popBoard[i];
            const cell = _popCells[i];
            if (!cell) continue;
            if (v > 0) {
                cell.className = 'cell';
                cell.textContent = String(v);
            } else {
                cell.className = 'cell empty';
                cell.textContent = '';
            }
        }
        const s = document.getElementById('pop-score');
        if (s) s.textContent = _popScore;
    }

    function rectStyle(r1, c1, r2, c2) {
        const left = PAD + c1 * PITCH;
        const top  = PAD + r1 * PITCH;
        const w = (c2 - c1 + 1) * CELL + (c2 - c1) * GAP;
        const h = (r2 - r1 + 1) * CELL + (r2 - r1) * GAP;
        return `left:${left}px;top:${top}px;width:${w}px;height:${h}px;`;
    }

    function renderHint() {
        const grid = document.getElementById('pop-grid');
        if (!grid) return;
        const old = grid.querySelector('.hint-box');
        if (old) old.remove();
        const idxEl = document.getElementById('pop-hint-idx');
        if (!_popPlan.length || _popPlanIdx >= _popPlan.length) {
            if (idxEl) idxEl.textContent = _popPlan.length ? `${_popPlan.length}/${_popPlan.length}` : '-';
            return;
        }
        const m = _popPlan[_popPlanIdx];
        const box = document.createElement('div');
        box.className = 'overlay hint-box';
        box.style.cssText = rectStyle(m.r1, m.c1, m.r2, m.c2);
        grid.appendChild(box);
        if (idxEl) idxEl.textContent = `${_popPlanIdx + 1}/${_popPlan.length}`;
    }

    function renderDragBox() {
        const grid = document.getElementById('pop-grid');
        if (!grid || !_popCellDrag) return;
        let box = grid.querySelector('.drag-box');
        if (!box) {
            box = document.createElement('div');
            box.className = 'overlay drag-box';
            grid.appendChild(box);
        }
        const r1 = Math.min(_popCellDrag.sr, _popCellDrag.er);
        const r2 = Math.max(_popCellDrag.sr, _popCellDrag.er);
        const c1 = Math.min(_popCellDrag.sc, _popCellDrag.ec);
        const c2 = Math.max(_popCellDrag.sc, _popCellDrag.ec);
        box.style.cssText = rectStyle(r1, c1, r2, c2);
    }

    function commitSelection(r1, c1, r2, c2) {
        if (!_popBoard || _popAnimating) return;
        let sum = 0, nz = 0;
        const cleared = [];
        for (let r = r1; r <= r2; r++) {
            for (let c = c1; c <= c2; c++) {
                const i = r*COLS + c;
                const v = _popBoard[i];
                if (v > 0) { sum += v; nz++; cleared.push(i); }
            }
        }
        if (nz === 0) { setPopMsg('빈 영역'); return; }
        if (sum !== 10) { setPopMsg(`합 ${sum} — 10이 아님`, 'bad'); return; }

        pushHistory();
        let hintMatch = false;
        if (_popPlan[_popPlanIdx]) {
            const m = _popPlan[_popPlanIdx];
            if (m.r1 === r1 && m.c1 === c1 && m.r2 === r2 && m.c2 === c2) hintMatch = true;
        }

        _popAnimating = true;
        cleared.forEach(i => {
            const cell = _popCells[i];
            if (cell) cell.classList.add('fading');
        });
        setTimeout(() => {
            cleared.forEach(i => { _popBoard[i] = 0; });
            _popScore += nz;
            if (hintMatch) _popPlanIdx++;
            renderBoard();
            renderHint();
            setPopMsg(`+${nz} 사과 (합 10)`, 'ok');
            _popAnimating = false;
        }, FADE_MS);
    }

    // ============================================
    // WebSocket 수신 (상태 감지 전용)
    // ============================================
    const OrigWS = window.WebSocket;
    window.WebSocket = function (...args) {
        const ws = new OrigWS(...args);
        if ((args[0] || '').includes(TARGET_URL)) {
            _ws = ws;
            uiLog('WebSocket 연결 감지'); uiStatus('연결됨');
            ws.addEventListener('message', (e) => handleMessage(e.data));
            ws.addEventListener('close', () => {
                uiStatus('연결 끊김'); uiLog('WebSocket 닫힘'); _ws = null;
            });
        }
        return ws;
    };
    window.WebSocket.prototype = OrigWS.prototype;
    Object.assign(window.WebSocket, OrigWS);

    function parseBoard(s) {
        const b = new Uint8Array(BOARD_SIZE);
        for (let i = 0; i < BOARD_SIZE; i++) b[i] = s.charCodeAt(i) - 48;
        return b;
    }

    function handleMessage(raw) {
        const j = String(raw).replace(/^\d+/, '');
        if (!j) return;
        try {
            const parsed = JSON.parse(j);
            if (!Array.isArray(parsed)) return;
            const [evt, p] = parsed;
            if (evt === 'game:started' || (evt === 'game:state' && p.phase === 'playing')) {
                if (!p.board) return;
                _lastBoard = parseBoard(p.board);
                _lastScore = p.score ?? 0;
                uiScore(_lastScore); uiStatus('게임 진행 중'); uiBtnState(false);
                uiLog(`${evt} (score: ${_lastScore})`);
                if (!_solveRunning) solveGame(_lastBoard, _lastScore);
            }
            if (evt === 'game:state' && p.phase !== 'playing') {
                uiStatus(`상태: ${p.phase}`); _lastBoard = null; uiBtnState(false);
            }
        } catch (e) { }
    }

    // ============================================
    // 풀이 → 팝업 표시
    // ============================================
    async function solveGame(board, currentScore) {
        if (_solveRunning) return;
        _solveRunning = true;
        _stopRequested = false;
        _bestIntermediate = null;
        uiBtnState(true);
        uiStatus('계산 중... (풀이 시작=지금까지 최고점 즉시 적용)');

        // 팝업을 먼저 띄워 사용자가 즉시 드래그할 수 있게 함
        _popInitial = board.slice();
        _popBoard = board.slice();
        _popPlan = [];
        _popPlanIdx = 0;
        _popScore = 0;
        _popHistory = [];
        _popAnimating = false;
        renderBoard();
        renderHint();
        setPopMsg('계산 중... (힌트는 완료되면 표시됨)');
        showBoardPopup();

        const t0 = Date.now();

        if (!_worker) createWorker();
        const result = await new Promise(resolve => {
            _solveResolve = resolve;
            _worker.postMessage({
                type: 'solve',
                board: Array.from(board),
                timeLimit: PLAN_TIME_LIMIT_MS
            });
        });

        if (_stopRequested || !result.plan || result.plan.length === 0) {
            uiStatus(_stopRequested ? '중지됨' : '결과 없음');
            setPopMsg(_stopRequested ? '계산 중지됨 (직접 플레이 가능)' : '해답 없음');
            _solveRunning = false;
            uiBtnState(false);
            return;
        }

        const elapsed = ((Date.now() - t0) / 1000).toFixed(1);
        if (result.earlyStop) {
            uiLog(`조기 적용: ${result.plan.length}개, ${result.score}점 (${elapsed}초)`);
            uiStatus('조기 적용 — 힌트 표시됨');
        } else {
            uiLog(`최종: ${result.plan.length}개, ${result.score}점 (${elapsed}초, 그리디+${result.score - result.greedyScore})`);
            uiStatus('계산 완료 — 힌트 표시됨');
        }

        _popPlan = result.plan.slice();
        // 사용자가 이미 진행한 수가 있을 수 있으니 plan idx는 현재 보드와 일치하는 첫 수를 찾지 않고 0으로 시작
        _popPlanIdx = 0;
        renderHint();
        setPopMsg(result.earlyStop
            ? `조기 적용: ${result.plan.length}개 계획 (${result.score}점) — 노란 점선 확인`
            : `계획 ${result.plan.length}개 로드됨 (${result.score}점) — 노란 점선 확인`);

        _solveRunning = false;
        uiBtnState(false);
    }

    // ============================================
    // 초기화
    // ============================================
    function init() {
        createUI();
        createBoardPopup();
        createWorker();
        uiLog('초기화 완료 — 팝업 드래그 모드');
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
